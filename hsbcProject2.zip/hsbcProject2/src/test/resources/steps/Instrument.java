package steps;

public class Instrument {

	private string  instid;
	private string instname;
	
	public String getinstid()
	{
	  return this.instid;
	}
	public void setinstid(String instid)
	{
		this.instid = instid;
	}
	public String getinstname()
	{
	  return this.instname;
	}
	public void setinstname(String instname)
	{
		this.instname = instname;
	}
}
